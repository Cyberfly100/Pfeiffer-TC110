from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.widget import Widget
from kivy.properties import ListProperty, NumericProperty, ObjectProperty, BooleanProperty
from kivy.graphics import Color, Line, Translate, Rotate, PushMatrix, PopMatrix, Mesh, Scale, Rectangle
from kivy.graphics import InstructionGroup
from kivy.core.text import Label as CoreLabel
from kivy.core.window import Window
from kivy.clock import Clock
import pfeifferTC110

class Content(FloatLayout):
    def __init__(self, **kwargs):
        super(FloatLayout, self).__init__(**kwargs)
        self.btn_state = False
        self.pump = pfeifferTC110.TC110()
    def toggle(self):
        if self.btn_state:
            self.ids.btn.text = "OFF"
            self.ids.btn.background_color = (0.95,0,0,1)
            self.btn_state = False
            self.pump.stop()
        else:
            self.ids.btn.text = "ON"
            self.ids.btn.background_color = (0,0.95,0,1)
            self.btn_state = True
            self.pump.start()
    def update_info(self,dt):
        speed = self.pump.get_speed()
        power = self.pump.get_power()
        self.ids.dial_gauge.value = speed
        self.ids.dial_gauge.power_value = power
    pass

class DialGauge(Widget):
    scale_max = NumericProperty(1700)
    scale_min = NumericProperty(0.0)
    scale_increment = NumericProperty(150.0)
    angle_start = NumericProperty(0.0)
    angle_stop = NumericProperty(360.0)
    angle_offset = NumericProperty(0.0)
    tic_frequency = NumericProperty(20.0)
    tic_length = NumericProperty(8)
    tic_width = NumericProperty(2)
    tic_radius = NumericProperty(100)
    tic_color = ListProperty([0,0,0])
    dial_color = ListProperty([1,1,1])
    needle_color = ListProperty([1,0,0])
    hub_color = ListProperty([1,0,0])
    needle_length = NumericProperty(100)
    needle_width = NumericProperty(4)
    hub_radius = NumericProperty(20)
    semi_circle = BooleanProperty(False)
    value = NumericProperty(0.0)
    value_offset_pos = ListProperty([0,0])
    show_value = BooleanProperty(True)
    value_color = ListProperty([0,0,0,1])

    def __init__(self, **kwargs):
        super(DialGauge, self).__init__(**kwargs)
        self.draw_annulars()
        self.draw_ticks()
        self.bind(pos=self._redraw, size=self._redraw)

    def _redraw(self, instance, value):
        self.canvas.before.remove(self.annulars)
        self.draw_annulars()
        self.canvas.remove(self.ticks)
        self.draw_ticks()

    def draw_annulars(self):
        self.annulars = InstructionGroup()

        # draw three annulars green, orange, red
        # TODO make this configurable
        awidth= 6
        self.annulars.add(Color(0, 1, 0, 0.8))
        self.annulars.add(Line(ellipse=(self.pos[0]+awidth, self.pos[1]+awidth, self.size[0]-awidth*2, self.size[1]-awidth*2, 100, 110), width=awidth, cap= 'none', joint='round'))
        self.annulars.add(Color(1, 0, 0, 0.8))
        self.annulars.add(Line(ellipse=(self.pos[0]+awidth, self.pos[1]+awidth, self.size[0]-awidth*2, self.size[1]-awidth*2, 110, 137), width=awidth, cap= 'none', joint='round'))
        self.annulars.add(Color(1, 0.7, 0, 0.8))
        self.annulars.add(Line(ellipse=(self.pos[0]+awidth, self.pos[1]+awidth, self.size[0]-awidth*2, self.size[1]-awidth*2, -20, 100), width=awidth, cap= 'none', joint='round'))
        self.annulars.add(Color(1, 0.7, 0, 0.4))
        self.annulars.add(Line(ellipse=(self.pos[0]+awidth, self.pos[1]+awidth, self.size[0]-awidth*2, self.size[1]-awidth*2, -86, -20), width=awidth, cap= 'none', joint='round'))

        self.canvas.before.add(self.annulars)

    def draw_ticks(self):
        scangle= self.angle_stop-self.angle_start
        inc= scangle / ((self.scale_max-self.scale_min)/self.scale_increment)
        inc /= self.tic_frequency
        cnt= 0

        # create an instruction group so we can remove it and recall draw_ticks to update when pos or size changes
        self.ticks = InstructionGroup()

        self.ticks.add(Color(*self.tic_color))

        labi = self.scale_min
        x= -180.0+self.angle_start+self.angle_offset # start
        while x <= self.angle_stop-180+self.angle_offset :
            a= x if(x < 0.0) else x+360.0

            need_label= True
            ticlen= self.tic_length

            if(cnt % self.tic_frequency != 0):
                ticlen= self.tic_length/2
                need_label= False

            cnt += 1

            self.ticks.add(PushMatrix())
            self.ticks.add(Rotate(angle=a, axis=(0,0,-1), origin=(self.center[0], self.center[1])))
            self.ticks.add(Translate(0, self.tic_radius-ticlen))
            self.ticks.add(Line(points=[self.center[0], self.center[1], self.center[0], self.center[1]+ticlen], width=self.tic_width, cap='none', joint='none'))

            if need_label:
                #print("label: " + str(labi))
                #kw['font_size'] = self.tic_length * 2
                label = CoreLabel(text=str(int(round(labi)))) #, **kw)
                label.refresh()
                texture= label.texture
                self.ticks.add(Translate(-texture.size[0]/2, -texture.size[1]-2))
                self.ticks.add(Rectangle(texture=texture, pos=self.center, size=texture.size))
                labi += self.scale_increment

            self.ticks.add(PopMatrix())
            x += inc

        self.canvas.add(self.ticks)

class PfeifferApp(App):
    def build(self):
        Window.size = (800,480)
        Window.fullscreen = True
        self.content = Content()
        Clock.schedule_interval(self.content.update_info, 0.4)
        return self.content

if __name__ == '__main__':
    application = PfeifferApp()
    application.run()
    application.content.pump.close()